package com.Attendance.student_sign_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentSignDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentSignDemoApplication.class, args);
	}

}
