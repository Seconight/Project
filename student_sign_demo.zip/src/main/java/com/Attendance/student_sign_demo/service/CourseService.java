package com.Attendance.student_sign_demo.service;

//课程服务接口类
public interface CourseService {

}
