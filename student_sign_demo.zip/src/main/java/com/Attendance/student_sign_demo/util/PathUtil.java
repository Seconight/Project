package com.Attendance.student_sign_demo.util;

public class PathUtil {
    //在此设置自己的cdc_face项目路径！
    public static String demoPath = "D:/Documents/demos/cdc_face/keras-face-recognition-master";
}
