package com.Attendance.student_sign_demo.dto;

public class CourseDTO {
}
