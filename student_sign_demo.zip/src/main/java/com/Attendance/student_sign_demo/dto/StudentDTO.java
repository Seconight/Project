package com.Attendance.student_sign_demo.dto;

//学生DTO，在学生注册时用，待完善
public class StudentDTO {

}
