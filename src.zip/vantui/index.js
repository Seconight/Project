//专门引入vantui组件
//导入Vant-UI
import Vue from 'vue'
import {Button,Icon,Tabbar,TabbarItem,Form,Field,Row,Col,RadioGroup,
    Radio,Toast,CellGroup,Cell,SwipeCell,Card ,Uploader,Image,Popup,
    Dialog,Collapse,CollapseItem,NavBar,ActionSheet,Tab,Tabs,Popover,
    Picker,Checkbox, CheckboxGroup,Search,DropdownMenu, DropdownItem,
    List,Grid, GridItem,NoticeBar,Step, Steps,Loading,Overlay         } from 'vant'
Vue.use(Button)
Vue.use(Icon)
Vue.use(Tabbar)
Vue.use(TabbarItem)
Vue.use(Form)
Vue.use(Field)
Vue.use(Row)
Vue.use(Col)


Vue.use(RadioGroup)
Vue.use(Radio)
Vue.use(Toast)
Vue.use(CellGroup)
Vue.use(Cell)
Vue.use(SwipeCell)
Vue.use(Card)
Vue.use(Uploader)
Vue.use(Image)
Vue.use(Popup)
Vue.use(Dialog)
Vue.use(Collapse)
Vue.use(CollapseItem)
Vue.use(NavBar)
Vue.use(ActionSheet)
Vue.use(Tab)
Vue.use(Tabs)
Vue.use(Popover)
Vue.use(Picker)


Vue.use(Checkbox);
Vue.use(CheckboxGroup);
Vue.use(Search);
Vue.use(DropdownMenu);
Vue.use(DropdownItem);
Vue.use(List);
Vue.use(Grid);
Vue.use(GridItem);
Vue.use(NoticeBar);
Vue.use(Step);
Vue.use(Steps); 
Vue.use(Loading);
Vue.use(Overlay);

