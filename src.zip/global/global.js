//定义全局变量
//const port = 'https://seconight.cn1.utools.club';
const port = 'http://localhost:8081'
var faceFile = new Array();
var studentFile = null;
var signFiles = new Array();

export default {
    port,
    faceFile,
    studentFile,
    signFiles,
}