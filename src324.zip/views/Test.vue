<template>
  <div class="usercenter-banner">
    <!-- <ImgLoader class="user-bg" :src="profile.background" v-if="loadflag" /> -->
    <img :src="assert.background" alt="" />
    <div class="_userinfo">
      <div class="_userinfo-avatar"><img :src="assert.avatarSrc" alt="" /></div>
      <div class="_userinfo-name">{{ name }}</div>
    </div>
    <input type="button" value="SkySquare" class="df-btn" />
    <van-grid :column-num="3" square v-if="role != ''" class="grid">
      <van-grid-item text="个人信息" to="/User/personalInfo">
        <template #icon>
          <van-icon :name="assert.gridImg[0]" size="40px" />
        </template>
      </van-grid-item>
      <van-grid-item icon="envelop-o" text="邮箱设置" to="/User/email">
        <template #icon>
          <van-icon :name="assert.gridImg[1]" size="40px" />
        </template>
      </van-grid-item>
      <van-grid-item
        icon="closed-eye"
        text="修改密码"
        @click="onChangePassword"
      >
        <template #icon>
          <van-icon :name="assert.gridImg[2]" size="40px" />
        </template>
      </van-grid-item>
      <van-grid-item
        v-if="role == '学生'"
        icon="smile-o"
        text="人脸上传"
        to="/User/faceUpload"
      >
        <template #icon>
          <van-icon :name="assert.gridImg[3]" size="40px" />
        </template>
      </van-grid-item>
      <van-grid-item icon="label-o" text="测试" to="/test" />
    </van-grid>
    <transition>
      <router-view @logout="logout"></router-view>
    </transition>
  </div>
</template>

<script>
//var axios = require('axios');
export default {
  data() {
    return {
      name: "点击登录",
      assert: {
        background: require("@/assets/user/background.jpg"),
        avatarSrc: require("@/assets/user/defualt.jpg"),
        gridImg: [
          require("@/assets/icon/gerenxinxi.png"),
          require("@/assets/icon/youxiangshezhi.png"),
          require("@/assets/icon/xiugaimima.png"),
          require("@/assets/icon/renlainshangchuan.png"),
        ],
      },

      //identity: '1',
      role: "",
      imgList: [],
      preview_options: {
        closeable: true,
      },
    };
  },
  created() {
    //进入user页面判断是否登录
    let userInfo = localStorage.getItem("userInfo");
    if (userInfo) {
      //存在已登录信息
      this.showinfor(); //更新组件信息显示
    }
  },

  methods: {
    onRead(file) {
      let content = file.file;
      this.GLOBAL.faceFile = content;
    },
    //组件个人信息显示
    showinfor() {
      let _userInfo = JSON.parse(localStorage.getItem("userInfo"));
      this.name = _userInfo.name;
      this.role = _userInfo.role;
      if (this.role == "老师") {
        this.avatarSrc = require("@/assets/user/teacher.jpg");
      }
      if (this.role == "学生") {
        this.avatarSrc = require("@/assets/user/student.jpg");
        this.checkFace = localStorage.getItem("checkFace");
      }
    },
    //上传人脸
    uploadface() {
      this.$dialog
        .confirm({
          title: "确定上传人脸数据",
        })
        .then(() => {
          // on confirm
          //上传人脸数据,只能上传一张照片
          var axios = require("axios");
          var FormData = require("form-data");
          var data = new FormData();
          data.append("faceImage", this.GLOBAL.faceFile);
          //console.log("this is "+this.GLOBAL.faceFile);
          data.append("studentId", this.id);

          var config = {
            method: "post",
            url: this.GLOBAL.port + "/user/faceInfo",
            headers: {
              //...data.getHeaders(),
              //设置请求头
              "Content-Type": "multipart/form-data",
            },
            data: data,
          };

          axios(config)
            .then(function (response) {
              console.log(JSON.stringify(response.data));
            })
            .catch(function (error) {
              console.log(error);
            });

          this.$toast.success("上传成功");
        })
        .catch(() => {
          // on cancel
        });
    },
    //登录
    onlogin() {
      this.$router.push("/login");
    },
    //退出登录事件
    onlogout() {
      this.$dialog
        .confirm({
          title: "确定要退出登录吗？",
        })
        .then(() => {
          // on confirm
          if (!localStorage.getItem("userInfo")) {
            this.$toast.fail("请先登录");
            return;
          }
          this.logout();
        })
        .catch(() => {
          // on cancel
        });
    },
    logout() {
      localStorage.removeItem("userInfo");
      localStorage.removeItem("checkFace");
      this.name = "点击登录";
      this.avatarSrc = require("@/assets/defualt.jpg");
      this.username = "";
      this.password = "";
      this.showLoginModal = false;
      this.role = "";
      this.imgList = [];
      this.preview_options.closeable = true;
    },
    onRegister() {
      this.showLoginModal = false;
    },
    onChangePassword() {
      let userInfo = JSON.parse(localStorage.getItem("userInfo"));
      if (userInfo.address == null) {
        this.$toast("邮箱未绑定!,请先绑定邮箱！");
      } else {
        this.$router.push("/User/changePassword");
      }
    },
  },
};
</script>
<style lang="less" scoped>
.usercenter-banner {
  position: relative;
  width: 100%;
  height: 40vh;
  &::before {
    content: "";
    position: absolute;
    top: 0;
    display: block;
    width: 100%;
    height: 60px;
    background: linear-gradient(to top, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.2));
  }
  .user-bg,
  & > img {
    position: absolute;
    width: 100%;
    height: 100%;
    border-radius: 0 0 36px 36px;
    overflow: hidden;
    z-index: 1;
  }
//   .df-btn {
//     position: absolute;
//     left: 0;
//     right: 0;
//     margin: auto;
//     bottom: -22px;
//     display: block;
//     width: 140px;
//     height: 38px;
//     border-radius: 44px;
//     background: crimson;
//     color: #fff;
//     border: none;
//     font-size: 0.875rem;
//     z-index: 3;
//   }
  ._userinfo {
    position: absolute;
    left: 0;
    right: 0;
    margin: auto;
    bottom: 100px;
    width: 100px;
    text-align: center;
    z-index: 3;
    ._userinfo-avatar {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      overflow: hidden;
      img {
          left: auto;
        width: 100%;
        height: 100%;
      }
    }
    ._userinfo-name {
    padding:10px;
      font-size: 1.125rem;
      font-weight: 600;
      color: #fff;
    }
  }
}
.grid {
  position: absolute;
  width: 100%;
  top: 40vh;
}
</style>
