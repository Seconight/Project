<template>
  <div>
    <div v-if="$route.path == '/user'">
      <van-row>
        <van-col span="6">
          <img :src="avatarSrc" alt="" />
        </van-col>
        <van-col span="10" @click="onlogin">{{ name }}</van-col>
        <!-- <van-col span='10' @submit="uploadface"> -->
        <van-col span="8" @click="onlogout">
          <van-icon name="cross" />
        </van-col>
      </van-row>
      <van-icon class-prefix="my-icon" name="yonghushezhi" />
      <img
        src="https://raw.githubusercontent.com/weilanwl/ColorUI/master/demo/images/wave.gif"
      />
      <van-grid :column-num="3" square v-if="role != ''">
        <van-grid-item text="个人信息" to="/User/personalInfo">
          <template #icon>
            <van-icon :name="gridImg[0]" size="40px" />
          </template>
        </van-grid-item>
        <van-grid-item icon="envelop-o" text="邮箱设置" to="/User/email">
          <template #icon>
            <van-icon :name="gridImg[1]" size="40px" />
          </template>
        </van-grid-item>
        <van-grid-item
          icon="closed-eye"
          text="修改密码"
          @click="onChangePassword"
        >
          <template #icon>
            <van-icon :name="gridImg[2]" size="40px" />
          </template>
        </van-grid-item>
        <van-grid-item
          v-if="role == '学生'"
          icon="smile-o"
          text="人脸上传"
          to="/User/faceUpload"
        >
          <template #icon>
            <van-icon :name="gridImg[3]" size="40px" />
          </template>
        </van-grid-item>
        <van-grid-item icon="label-o" text="测试" to="/test" />
      </van-grid>
    </div>
    <transition>
      <router-view @logout="logout"></router-view>
    </transition>
  </div>
</template>

<script>
//var axios = require('axios');
export default {
  data() {
    return {
      name: "点击登录",
      avatarSrc: require("@/assets/defualt.jpg"),
      gridImg: [
        require("@/assets/icon/gerenxinxi.png"),
        require("@/assets/icon/youxiangshezhi.png"),
        require("@/assets/icon/xiugaimima.png"),
        require("@/assets/icon/renlainshangchuan.png"),
      ],
      //identity: '1',
      role: "",
      imgList: [],
      preview_options: {
        closeable: true,
      },
    };
  },
  created() {
    //进入user页面判断是否登录
    let userInfo = localStorage.getItem("userInfo");
    if (userInfo) {
      //存在已登录信息
      this.showinfor(); //更新组件信息显示
    }
  },

  methods: {
    onRead(file) {
      let content = file.file;
      this.GLOBAL.faceFile = content;
    },
    //组件个人信息显示
    showinfor() {
      let _userInfo = JSON.parse(localStorage.getItem("userInfo"));
      this.name = _userInfo.name;
      this.role = _userInfo.role;
      if (this.role == "老师") {
        this.avatarSrc = require("@/assets/teacher.jpg");
      }
      if (this.role == "学生") {
        this.avatarSrc = require("@/assets/student.jpg");
        this.checkFace = localStorage.getItem("checkFace");
      }
    },
    //上传人脸
    uploadface() {
      this.$dialog
        .confirm({
          title: "确定上传人脸数据",
        })
        .then(() => {
          // on confirm
          //上传人脸数据,只能上传一张照片
          var axios = require("axios");
          var FormData = require("form-data");
          var data = new FormData();
          data.append("faceImage", this.GLOBAL.faceFile);
          //console.log("this is "+this.GLOBAL.faceFile);
          data.append("studentId", this.id);

          var config = {
            method: "post",
            url: this.GLOBAL.port + "/user/faceInfo",
            headers: {
              //...data.getHeaders(),
              //设置请求头
              "Content-Type": "multipart/form-data",
            },
            data: data,
          };

          axios(config)
            .then(function (response) {
              console.log(JSON.stringify(response.data));
            })
            .catch(function (error) {
              console.log(error);
            });

          this.$toast.success("上传成功");
        })
        .catch(() => {
          // on cancel
        });
    },
    //登录
    onlogin() {
      this.$router.push("/login");
    },
    //退出登录事件
    onlogout() {
      this.$dialog
        .confirm({
          title: "确定要退出登录吗？",
        })
        .then(() => {
          // on confirm
          if (!localStorage.getItem("userInfo")) {
            this.$toast.fail("请先登录");
            return;
          }
          this.logout();
        })
        .catch(() => {
          // on cancel
        });
    },
    logout() {
      localStorage.removeItem("userInfo");
      localStorage.removeItem("checkFace");
      this.name = "点击登录";
      this.avatarSrc = require("@/assets/defualt.jpg");
      this.username = "";
      this.password = "";
      this.showLoginModal = false;
      this.role = "";
      this.imgList = [];
      this.preview_options.closeable = true;
    },
    onRegister() {
      this.showLoginModal = false;
    },
    onChangePassword() {
      let userInfo = JSON.parse(localStorage.getItem("userInfo"));
      if (userInfo.address == null) {
        this.$toast("邮箱未绑定!,请先绑定邮箱！");
      } else {
        this.$router.push("/User/changePassword");
      }
    },
  },
};
</script>

<style lang='less' scoped>
.van-row {
  height: 100px;
  padding: 10px;
  background: linear-gradient(to right, #ff0000, #000000);
  color: #fff;
  .van-col {
    height: 100px;
    line-height: 100px;
    font-size: 20px;
    text-align: center;
    img {
      width: 100px;
      border-radius: 50%;
    }
    &:last-child {
      text-align: right;
    }
  }
}
.login_modal {
  width: 100%;
  height: 100vh;
  position: absolute;
  left: 0;
  top: 0;
  section {
    width: 100%;
    height: 100vh;
    background: rgba(0, 0, 0, 0.5);
  }
  .van-form {
    width: 90%;
    position: absolute;
    top: 30vh;
    left: 5%;
    padding: 10px;
    box-sizing: border-box;
    background: #fff;
  }
}
</style>