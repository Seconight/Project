<template>
  <van-row style="text-align: center;  font-weight: bold">
    <van-col span="8">学号</van-col>
    <van-col span="8">姓名</van-col>
    <van-col span="8">班级</van-col>
  </van-row>
</template>

<script>
export default {};
</script>

<style>
</style>